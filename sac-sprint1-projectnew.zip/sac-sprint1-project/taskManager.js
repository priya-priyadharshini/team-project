class TaskManager {

    constructor() {

        this.tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    }

    addTask(task) {

        this.tasks.push(task);
        this.saveToLocalStorage();
    }

    deleteTask(id) {

        this.tasks = this.tasks.filter(task => task.id != id);
        this.saveToLocalStorage();
    }

    updateTask(updatedTask) {

        this.tasks = this.tasks.map(task =>
            task.id == updatedTask.id ? updatedTask : task
        );

        this.saveToLocalStorage();
    }

    saveToLocalStorage() {

        localStorage.setItem("tasks", JSON.stringify(this.tasks));
    }

    getAllTasks() {

        return this.tasks;
    }
}