const manager = new TaskManager();

function testAddTask(){

    let lengthBefore = manager.tasks.length;

    manager.addTask({
        id:1,
        name:"Test Task"
    });

    console.log(
        manager.tasks.length > lengthBefore
            ? "Add Task Test Passed"
            : "Add Task Test Failed"
    );
}

function testDeleteTask(){

    manager.deleteTask(1);

    let task = manager.tasks.find(task => task.id == 1);

    console.log(
        !task
            ? "Delete Task Test Passed"
            : "Delete Task Test Failed"
    );
}

function testUpdateTask(){

    manager.addTask({
        id:2,
        name:"Old Task"
    });

    manager.updateTask({
        id:2,
        name:"Updated Task"
    });

    let task = manager.tasks.find(task => task.id == 2);

    console.log(
        task.name === "Updated Task"
            ? "Update Task Test Passed"
            : "Update Task Test Failed"
    );
}

testAddTask();
testDeleteTask();
testUpdateTask();