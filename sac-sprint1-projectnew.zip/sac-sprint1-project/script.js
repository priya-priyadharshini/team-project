const taskManager = new TaskManager();

const taskForm = document.getElementById("taskForm");

displayTasks();

taskForm.addEventListener("submit", function(event){

    event.preventDefault();

    let id = document.getElementById("taskId").value;

    let name = document.getElementById("name").value.trim();
    let description = document.getElementById("description").value.trim();
    let assignedTo = document.getElementById("assignedTo").value.trim();
    let dueDate = document.getElementById("dueDate").value;
    let status = document.getElementById("status").value;
    let priority = document.getElementById("priority").value;

    clearErrors();

    let isValid = true;

    if(name === ""){
        document.getElementById("nameError").innerText = "Task name required";
        isValid = false;
    }

    if(description === ""){
        document.getElementById("descriptionError").innerText = "Description required";
        isValid = false;
    }

    if(assignedTo === ""){
        document.getElementById("assignedError").innerText = "Assigned To required";
        isValid = false;
    }

    if(dueDate === ""){
        document.getElementById("dateError").innerText = "Due date required";
        isValid = false;
    }

    if(status === ""){
        document.getElementById("statusError").innerText = "Select status";
        isValid = false;
    }

    if(priority === ""){
        document.getElementById("priorityError").innerText = "Select priority";
        isValid = false;
    }

    if(!isValid){
        return;
    }

    const task = {
        id: id || Date.now(),
        name,
        description,
        assignedTo,
        dueDate,
        status,
        priority
    };

    if(id){

        taskManager.updateTask(task);

        document.getElementById("submitBtn").innerText = "Save Task";

    } else {

        taskManager.addTask(task);
    }

    displayTasks();

    taskForm.reset();

    document.getElementById("taskId").value = "";
});

function displayTasks(){

    let taskList = document.getElementById("taskList");

    taskList.innerHTML = "";

    taskManager.getAllTasks().forEach(task => {

        let urgentClass = task.priority === "URGENT"
            ? "urgent-card"
            : "";

        taskList.innerHTML += `
        
        <div class="col-md-4 mb-3">

            <div class="card shadow ${urgentClass}">

                <div class="card-body">

                    <h5>${task.name}</h5>

                    <p>${task.description}</p>

                    <p><strong>Assigned To:</strong> ${task.assignedTo}</p>

                    <p><strong>Due Date:</strong> ${task.dueDate}</p>

                    <p><strong>Status:</strong> ${task.status}</p>

                    <p><strong>Priority:</strong> ${task.priority}</p>

                    <button class="btn btn-warning btn-sm"
                        onclick="editTask(${task.id})">
                        Edit
                    </button>

                    <button class="btn btn-danger btn-sm"
                        onclick="deleteTask(${task.id})">
                        Delete
                    </button>

                </div>

            </div>

        </div>
        `;
    });
}

function editTask(id){

    const task = taskManager.tasks.find(task => task.id == id);

    document.getElementById("taskId").value = task.id;
    document.getElementById("name").value = task.name;
    document.getElementById("description").value = task.description;
    document.getElementById("assignedTo").value = task.assignedTo;
    document.getElementById("dueDate").value = task.dueDate;
    document.getElementById("status").value = task.status;
    document.getElementById("priority").value = task.priority;

    document.getElementById("submitBtn").innerText = "Update Task";
}

function deleteTask(id){

    taskManager.deleteTask(id);

    displayTasks();
}

function clearErrors(){

    document.getElementById("nameError").innerText = "";
    document.getElementById("descriptionError").innerText = "";
    document.getElementById("assignedError").innerText = "";
    document.getElementById("dateError").innerText = "";
    document.getElementById("statusError").innerText = "";
    document.getElementById("priorityError").innerText = "";
}